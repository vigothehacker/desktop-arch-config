### [Alacritty](https://github.com/jwilm/alacritty)

#### Install

Download using the [GitHub .zip download](https://github.com/dracula/alacritty/archive/master.zip) option.

You just have to replace the colors section in `~/.config/alacritty/alacritty.yml` with this.